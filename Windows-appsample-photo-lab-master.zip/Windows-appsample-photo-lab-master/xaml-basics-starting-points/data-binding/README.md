# XAML basics: create data bindings - sample code

This sample represents the starting point for [XAML basics: create data bindings](https://docs.microsoft.com/windows/uwp/get-started/xaml-basics-data-binding).

